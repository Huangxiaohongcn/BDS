// pages/home/home.js
var app = getApp();
//wifi
var wifiSSID = "";
var wifiPsw = "";
var wifiIndex = "";
var wifiBSSID = "";
var defServWifiID = "192.168.4.1";
var defServWifiPort = 8266;
var wifiIP = "";
var wifiPort = "";
var iosInitWifiFlag ='';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //Button
    searchButton1: "扫描蓝牙",
    searchButton2:"扫描WiFi",
    //蓝牙
    devices: [],//搜索到的各个蓝牙设备
    devId: "",//使用的蓝牙设备名字
    rightService: 1,//选择到蓝牙正确服务的标记
    serviceUUID: "",//蓝牙服务的UUID
    notifyCharacterId: "",//蓝牙接收信号的特征值
    writeCharacterId: "",//蓝牙发送信号的特征值

    //wifi
     wifiList: [
     ],
    servWifiID : "",
    servWifiPort : 0,
    InputbgHide: 1,
    wifiIndexToWxml: 0,
  },

  startScan: function () {   //按键按下
    var that = this;
    that.setData({
      wifiList:[]
    })
      that.openBluetoothAdapter();
  },

  //打开蓝牙适配器
  openBluetoothAdapter: function () {
    var that = this;
    wx.openBluetoothAdapter({
      success: function (res) {
        that.getBluetoothAdapterState();//获取本机蓝牙适配器状态
      },
      fail: function (err) {
        if (app.globalData.isIOS == "") {
          app.showModal1("蓝牙开关未开启");
        }
        if (app.globalData.isIOS != "") {
          wx.showModal({
            title: '提示',
            content: '蓝牙开关未开启,\r\n如果已经打开,请重新打开',
            showCancel: false,
          })
        } 
      }
    })
  }, 
   //获取本机蓝牙适配器状态
  getBluetoothAdapterState: function () {
    var that = this;
    wx.getBluetoothAdapterState({
      success: function (res) {
        app.globalData.AdapterStateflag = 1;
        var isDvailable = res.available; //蓝牙适配器是否可用
        if (isDvailable) {
          that.startBluetoothDevicesDiscovery();//开始扫描附近的蓝牙外围设备
        }
      }
    })
  },

  //开始扫描附近的蓝牙外围设备
  startBluetoothDevicesDiscovery: function () {
    var that = this;
    wx.startBluetoothDevicesDiscovery({
      //services: ['180A'], //如果填写了此UUID，那么只会搜索出含有这个UUID的设备，建议一开始先不填写
      success: function (res) {
        that.getBluetoothDevices();//扫描附近的蓝牙外围设备API
      }
    });
    app.showLoading("正在扫描..");
    setTimeout(function () {
      wx.hideLoading(); //隐藏loading
    }, 1000);
    that.onBluetoothDeviceFound();//监听寻找到新设备的事件
  },
  //开始扫描附近的蓝牙外围设备
  getBluetoothDevices(event) {
    var that = this;
    that.stopSearchWifi()
    wx.getBluetoothDevices({
      success: function (res) {
        that.setData({
          devices: res.devices
        })
      }
    })
  }, 
  //监听寻找到新设备的事件
  onBluetoothDeviceFound: function () {
    var that = this;
    wx.onBluetoothDeviceFound(function (res) {
      res.devices.forEach(function (device) {
        if (!device.name && !device.localName) {
          return
        }
        const foundDevices = that.data.devices;  //已搜索到的设备
        const idx = inArray(foundDevices, 'deviceId', device.deviceId);  //判断，已搜索到的设备和现在搜索的对比，一样返回 i ，不一样返回-1
        const data = {};
        if (idx === -1) {
          data[`devices[${foundDevices.length}]`] = device  //向拓容的数组加入新的设备
        } else {
          data[`devices[${idx}]`] = device    //更新已经搜索到的设备
        }
        that.setData(data)    //重新设置data数字的设备
      })
    })
  },

  //点击链接蓝牙
  createBLEConnection: function (e) {
    var that = this;
    const ds = e.currentTarget.dataset;
    const deviceId = ds.deviceId; //设备UUID
    const name = ds.name; //设备名
    // that.stopConnectDevices();  //配对之前先断开已连接设备
    // app.showLoading("正在连接，请稍后");
    if (app.globalData.createflag != deviceId){
      that.closeBLEConnection(); //关闭上次连接
      app.globalData.createflag = "";           //清除上次标记
      app.showLoading("连接中..");
      wx.createBLEConnection({
        deviceId: deviceId,
        success: function (res) {
          app.globalData.sendfail = 0;
          app.globalData.jumpflag = 1;
          app.globalData.sendBleFlag = 1;
          app.globalData.sendWifiFlag = 0;
          app.globalData.createflag = deviceId;      //成功连接则重新赋值
          wx.hideLoading(); //隐藏loading
          app.showModal1("连接成功，请点击操控机器人");
          that.setData({
            name,
            devId: deviceId
          });
          that.getBLEDeviceServices(deviceId)
          that.stopBluetoothDevicesDiscovery(); //停止搜索
        },

        fail: function (err) {
          app.globalData.jumpflag = 0;
          wx.hideLoading(); //隐藏loading
          if (err.errCode === 10012) {
            app.showModal1("连接超时,请重试!");
          } else if (err.errCode === 10013) {
            app.showModal1("连接失败,蓝牙地址无效!");
          } else {
            if (app.globalData.AdapterStateflag == 1){
              app.showModal1("连接失败,请重试!"); // + err.errCode10003原因多种：蓝牙设备未开启或异常导致无法连接;蓝牙设备被占用或者上次蓝牙连接未断开导致无法连接
            }else{  //手机蓝牙未打开
              app.showModal1("请打开手机蓝牙");
            }
          }
          that.closeBLEConnection()//关闭连接
        },
      });
    }else{
      app.globalData.jumpflag = 0;
      that.closeBLEConnection()//关闭连接
      app.showModal1("断开"+name );
      app.globalData.createflag = "";
    }
  },
   //停止搜索
  stopBluetoothDevicesDiscovery: function () {
    var that = this;
    wx.stopBluetoothDevicesDiscovery();
  },
  //关闭连接
  closeBLEConnection: function () {
    wx.closeBLEConnection({
      deviceId: this.data.devId
    })
  },
  //获取蓝牙设备所有 service（服务）
  getBLEDeviceServices: function (deviceId) {
    var that = this;
    wx.getBLEDeviceServices({
      deviceId: deviceId,
      success: function (res) {
        for (let i = 0; i < res.services.length; i++) {
          if (res.services[i].isPrimary) { //该服务是否为主服务
            //console.log("服务UUID ：" + res.services[i].uuid + "\n");
            that.getBLEDeviceCharacteristics(res.services[i].uuid);  //获取特征值
          } 
        }
      }
    })
  },
  //获取特征值
  getBLEDeviceCharacteristics: function (serId){
    var that = this;
    //console.log("服务UUID ：" + serId + "\n");
    wx.getBLEDeviceCharacteristics({
      // 这里的 devId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.devId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: serId,
      success: function (res) {
        if (that.data.rightService == 1){     //选择到蓝牙正确服务的标记
          that.setData({
            writeCharacteristicsId: "",
            notifyCharacteristicsId: ""
          });
        }
        for (var i = 0; i < res.characteristics.length; i++) {    //遍历特征值
          if (res.characteristics[i].properties.notify) {         //写入特征
            that.setData({
              notifyCharacteristicsId: res.characteristics[i].uuid,
            })
          }
          if (res.characteristics[i].properties.write) {           //通知特征
            that.setData({
              writeCharacteristicsId: res.characteristics[i].uuid
            })
          }
          if (that.data.rightService==1){
            if (that.data.writeCharacteristicsId && that.data.notifyCharacteristicsId) {     //写入特征和通知特征都可用的
              that.setData({
                rightService: 0,     //选择到蓝牙正确服务的标记置零
                serviceUUID: serId,
                notifyCharacterId: that.data.writeCharacteristicsId,
                writeCharacterId: that.data.notifyCharacteristicsId 
              })
              console.log("设备ID ：" + that.data.devId + "\n");
              console.log("服务UUID ：" + serId + "\n");
              console.log("写入特征值 ：" + that.data.writeCharacterId + "\n");
              console.log("通知特征值 ：" + that.data.notifyCharacterId + "\n");
            }
          }
        }
      },
      fail: function () {
        console.log("fail");
      },
    })
  },

  startcontrol:function(){
    var that = this;
    //if (app.globalData.jumpflag == 1) {
      wx.navigateTo({
        url: '/pages/concrolPagewxs/concrolPagewxs?name=' + encodeURIComponent(that.data.name) +
          '&deviceId=' + encodeURIComponent(that.data.devId) +
          '&serviceId=' + encodeURIComponent(that.data.serviceUUID) +
          '&writeCharacterId=' + encodeURIComponent(that.data.writeCharacterId) +
          '&notifyCharacterId=' + encodeURIComponent(that.data.notifyCharacterId)
      });
    //}else{
    // app.showModal1("请连接蓝牙");
    //}
  },

  //WIFI
  startSearchWiFi() {
    var that = this;
    that.stopBluetoothDevicesDiscovery(); 
    that.setData({
      devices: [],
    })
    const getWifiList = () => {
      wx.getWifiList({
        success: (res) => {
          wx.onGetWifiList((res) => {
            const wifiList = res.wifiList
              .sort((a, b) => b.signalStrength - a.signalStrength)
              .map(wifi => {
                const strength = Math.ceil(wifi.signalStrength * 4 / 100)
                return Object.assign(wifi, { strength })
              })
            this.setData({
              wifiList
            })
          })
        },
        fail(err) {
          console.error(err);
          if (err.errCode == 12005) {
            app.showModal("请打开wifi");
          }
          if (err.errCode == 12006) {
            app.showModal1("请打开定位");
          }
        }
      })
    }

    const startWifi = () => {
      wx.startWifi({
        success(res){
          if (app.globalData.isIOS == ""){
            getWifiList();
            }
          if (app.globalData.isIOS != "") {
            app.globalData.jumpflag = 1
            app.globalData.sendBleFlag = 0;
            app.globalData.sendWifiFlag = 1;
            if (iosInitWifiFlag == ''){
              wx.showModal({
                title: '初始化成功',
                content: '但由于系统限制，iOS用户请手动进入系统WiFi页面连接对应设备',
                showCancel: false,
              })
            }
          }
        },
        fail(err) {
          console.error(err);
        }
      })
    };

    startWifi()

    // wx.getSystemInfo({
    //   success(res) {
    //     if (res.system.substr(0, 3) == "iOS"){
    //       isIOS = res.system.substr(4,4);
    //       if (isIOS == "11.0" || isIOS == "11.1") {
    //         wx.showModal({
    //           title: '提示',
    //           content: '由于系统限制，iOS 11.0和iOS 11.1用户请手动进入系统WiFi页面连接对应设备',
    //           showCancel: false,
    //           success() {                
    //             startWifi()
    //           }
    //         })
    //         return
    //       }
    //     }
    //     startWifi()
    //   }
    // })
  },

  stopSearchWifi() {
    wx.offGetWifiList((res)=>{
     console.log(res)
    })
  },

  bindWiFiBtn: function (res) {
    var that = this;
    wifiIndex = res.currentTarget.dataset.idx
    that.setData({
      InputbgHide: 0,
      wifiIndexToWxml: wifiIndex
    })
  },

  getWifiPsw: function (t) {
    var that = this;
    wifiPsw = t.detail.value
  },

  cancelWifiInp: function (t) {
    var that = this;
    that.setData({
      InputbgHide: 1,
      'Psw': ""
    })
    wifiPsw = "";
  },

  confirmWifiInp: function (t) {
    var that = this;
    if (wifiPsw){
      that.setData({
        InputbgHide: 1,
        'Psw': ""
      })
      wifiSSID = that.data.wifiList[wifiIndex].SSID;
      wifiBSSID = that.data.wifiList[wifiIndex].BSSID;
      that.connectWifi();
    }
  },
  connectWifi: function () {
    wx.connectWifi({
      SSID: wifiSSID,
      BSSID: wifiBSSID,
      password: wifiPsw,
      success: function (res) {
        app.globalData.jumpflag = 1
        app.globalData.sendBleFlag = 0;
        app.globalData.sendWifiFlag = 1;
        app.showModal("连接成功，请点击操控机器人");
        wifiPsw = "";
      },
      fail: function (res) {
        console.log(res)
        if (res.errCode == 12002) {
          app.showModal("连接超时，请重试");
        }
        if (res.errCode == 12003) {
          app.showModal1("密码错误");
        }
        wifiPsw = "";
      },
    })
  },
  // 左侧隐藏栏
  openleftHidePg: function (e) {
    if (this.data.leftHidePgOpen) {
      this.setData({
        leftHidePgOpen: false
      });
    } else {
      this.setData({
        leftHidePgOpen: true
      });
    }
    var that = this;
    that.setData({
      servWifiId: app.globalData.servWifiID,
      servWifiPort: app.globalData.servWifiPort
    })
  },
  hideLeftPg: function(){
      if (this.data.leftHidePgOpen) {
          this.setData({
            leftHidePgOpen: false
          });
      }
  },
  getInpWifiIP: function(res){
    wifiIP = res.detail.value
  },
  getInpWifiPort: function (res) {
    wifiPort = res.detail.value
  },
  confirmWifiIpAndPort: function () {
      var that = this;
    if (wifiIP){
          app.globalData.servWifiID = wifiIP;
        that.setData({
          servWifiId: app.globalData.servWifiID,
        })
        wifiIP = "";
      }
    if (wifiPort) {
      app.globalData.servWifiPort = wifiPort;
      that.setData({
        servWifiPort: app.globalData.servWifiPort,
      })
      wifiPort = "";
    }
  },
  cancelWifiIpAndPort: function () {
    app.globalData.servWifiID = defServWifiID;
    app.globalData.servWifiPort = defServWifiPort;
    var that = this;
    that.setData({
      servWifiId: app.globalData.servWifiID,
      servWifiPort: app.globalData.servWifiPort,
      InpWifiIP: '',
      InpWifiPort: ''
    })
    wifiIP = "";
    wifiPort = "";
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success(res) {
        if (res.system.substr(0, 3) == "iOS") {
          app.globalData.isIOS = 1
          that.setData({
            searchButton2: "初始化WiFi"
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
    // wx.navigateTo({
    //   url: '/pages/concrolPagewxs/concrolPagewxs?name=' + encodeURIComponent('BT05') +
    //   '&deviceId=' + encodeURIComponent('00:13:AA:00:91:B2') + 
    //   '&serviceId=' + encodeURIComponent('0000FFE0-0000-1000-8000-00805F9B34FB') + 
    //     '&writeCharacterId=' + encodeURIComponent('0000FFE1-0000-1000-8000-00805F9B34FB') + 
    //     '&notifyCharacterId=' + encodeURIComponent('0000FFE1-0000-1000-8000-00805F9B34FB')
    // });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    this.stopSearchWifi();
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i;
    }
  }
  return -1;
}