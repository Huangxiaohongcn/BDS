// pages/concrolPagewxs/concrolPagewxs.js
var app = getApp();
var lastLeft = 130;       //初始点x  
var lastBottom = 100;    //初始点距底部距离
var ganimgHeight = 80;   //图片高度
var lastTopThis = 0;     //同lastTop    //定时变量
var stop = 0;            //定时的停止标志
var setInter1 = null;    //定时循环

//来自home页的数据
var name = '';
var deviceId = '';
var serviceId = '';
var writeId = '';
var notifyId = '';

//wifi
var udpSocket = "";

Page({
  /**
   * 页面的初始数据
   */
  data: {
    //要传给wxs的数据
    lastTop: 0,
  },

//触碰到图片时执行
  Imagestart: function (options) {
    var that = this;
    var left = lastLeft;
    var top = lastTopThis
    var angle = 0;
    var sendMsg = 0;
    var sendWifiMsg = "";
    clearInterval(setInter1);  //点击不移动会一直存在一个定时循环，下一个点击将通过此关掉定时循环同时如果移动则不会进入新的定时循环
     setInter1 = setInterval(() => {   //循环执行
      //创建节点选择器
      var query = wx.createSelectorQuery();
      query.select('#pic_gan').boundingClientRect()   //获取摇杆的信息
      query.exec(function (res) {
        left = res[0].left;
        top = res[0].top;
      })
      
      // if (left != lastLeft && top != lastTopThis){    //如果一开始按着不动会马上停止，所以加个判断
      //    stop = 1;
      //  };
      // //当摇杆停止后关闭定时器
      //  if(stop == 1){
      //     //因为有些手机的初始位置值有些差1、2个px，故校正一下
      //    if (left == lastLeft && (top == lastTopThis || top == lastTopThis + 1 || top == lastTopThis - 1 )) {
      //     clearInterval(setInter1);     //停止定时
      //     stop = 0;
      //     left = lastLeft;
      //     top = lastTopThis;
      //   }
      //  };
      angle = that.GetAngle(left - lastLeft,top - lastTopThis).angle;    //获取角度
      //获取要发送的信息
       if (app.globalData.sendBleFlag == 1){
      sendMsg = that.getSendmsg(angle, Math.sqrt((left - lastLeft) * (left - lastLeft) + (top - lastTopThis) * (top - lastTopThis) )).sendMsg;
         that.sentOrder(sendMsg);    //向蓝牙发送信息
      }
       if (app.globalData.sendWifiFlag == 1){
       sendWifiMsg = that.getSendmsg(angle, Math.sqrt((left - lastLeft) * (left - lastLeft) + (top - lastTopThis) * (top - lastTopThis))).sendWifiMsg;
         that.sendWifiMessage(sendWifiMsg);
       } 
    }, 100)
  },
  //中间按键点击停下逻辑
  MidBtnSend: function(){
    var that = this;
    if (app.globalData.sendBleFlag == 1)
      that.sentOrder(0);
    if (app.globalData.sendWifiFlag == 1)
      that.sendWifiMessage("S")
  },
  stpMidBtnSend: function(){
    clearInterval(setInter1);
  },
  sentOrder: function (Taglist) {
    var that = this;
    let buffer = that.hexStringToArrayBuffer(Taglist);
    that.writeBLECharacteristicValue(buffer);
  },
  writeBLECharacteristicValue(e) {
    var that = this
    wx.writeBLECharacteristicValue({
      deviceId: deviceId,
      serviceId: serviceId,
      characteristicId: writeId,
      // 这里的value是ArrayBuffer类型
      value: e,
      success: function (res) {
        //console.log('写入成功', res.errMsg)
      },
      fail(res) {
        app.globalData.sendfail++;
        if ((app.globalData.sendfail == 1 || app.globalData.sendfail == 13 || app.globalData.sendfail == 33) && app.globalData.jumpflag == 1) {       //onBLEConnectionStateChange20s左右才能回调得到异常断开的反馈所以用此方法代替
          app.globalData.jumpflag = 0;
          app.globalData.createflag = "";
          app.showModal1(name + "连接已断开，请重新连接")   
        }
        console.log('写入失败', res.errMsg)
      }
    })
  },
  //手机蓝牙状态发生变化
  onBluetoothAdapterStateChange: function () {
    wx.onBluetoothAdapterStateChange(function (res) { 
      if (res.available == 0 && sendWifiFlag == 0){
        app.globalData.jumpflag = 0;
        app.globalData.createflag = "";
        app.globalData.AdapterStateflag = 0;
        app.showModal1("手机蓝牙已关闭");
      }
    });
  },
  //连接状况发生变化
  // onBLEConnectionStateChange: function () {       //onBLEConnectionStateChange20s左右才能回调得到异常断开的反馈
  //   wx.onBLEConnectionStateChange(function (res) {
  //     // 该方法回调中可以用于处理连接意外断开等异常情况
  //     if (res.connected == 0) {
  //       app.globalData.jumpflag = 0;
  //       app.globalData.createflag = "";
  //       app.showModal1(name +"断开")
  //     }
  //   })
  // },

  //向蓝牙设备发送一个0x00的16进制数据
  hexStringToArrayBuffer: function (t) {
    let buffer = new ArrayBuffer(1);
    let dataView = new DataView(buffer);
    dataView.setUint8(0, t);
    return buffer
  },
  //获取角度
  GetAngle: function (D_X, D_Y) {
    var angleTan;
    var ang;
    var angs;
    var result;
    var self = this;
    if (D_X > 0 && D_Y <= 0) {
      angleTan = D_Y / D_X * -1;
      ang = Math.atan(angleTan);
      angs = ang * 180 / 3.14;
      result = Math.round(angs);
    }

    if (D_X < 0 && D_Y <= 0) {
      angleTan = D_Y / D_X * -1;
      ang = Math.atan(angleTan);
      angs = 180 + ang * 180 / 3.14;
      result = Math.round(angs);
    }

    if (D_X < 0 && D_Y > 0) {
      angleTan = D_Y / D_X * -1;
      ang = Math.atan(angleTan);
      angs = 180 + ang * 180 / 3.14;
      result = Math.round(angs);
    }

    if (D_X > 0 && D_Y > 0) {
      angleTan = D_Y / D_X * -1;
      ang = Math.atan(angleTan);
      angs = 360 + ang * 180 / 3.14;
      result = Math.round(angs);
    }
    if (D_X == 0 && D_Y > 0) {
      result = 270;
    }
    if (D_X == 0 && D_Y < 0) {
      result = 90;
    }
    if (D_X == 0 && D_Y == 0) {
      result = ""
    }
    return { angle: result};
  },

  //获取要发送给蓝牙的数据
  getSendmsg: function (Angle, z) {
    var send;
    var sendWifi;
    var self = this;
    if (z > 25 && Angle >= 225 && Angle < 315) {
      send = 3;
      sendWifi = "B"
    } else if (z > 25 && Angle >= 45 && Angle < 135) {
      send = 1;
      sendWifi = "F"
    } else if (z > 25 && Angle >= 0 && Angle < 45 || Angle >= 315) {
      send = 2;
      sendWifi = "R"
    } else if (z > 25 && Angle >= 135 && Angle < 225) {
      send = 4;
      sendWifi = "L"
    }else{
      send = "";
      sendWifi = ""
    }
    return { 
      sendMsg: send,
      sendWifiMsg: sendWifi
    };
  },

  bindImgA: function (){
    var that = this;
    if (app.globalData.sendBleFlag == 1)
    that.sentOrder(10);
    if (app.globalData.sendWifiFlag == 1)
    that.sendWifiMessage("a")
  },
  bindImgB: function () {
    var that = this;
    if (app.globalData.sendBleFlag == 1)
      that.sentOrder(11);
    if (app.globalData.sendWifiFlag == 1)
      that.sendWifiMessage("b")
  },
  bindImgC: function () {
    var that = this;
    if (app.globalData.sendBleFlag == 1)
      that.sentOrder(12);
    if (app.globalData.sendWifiFlag == 1)
      that.sendWifiMessage("c")
  },
  bindImgD: function () {
    var that = this;
    if (app.globalData.sendBleFlag == 1)
      that.sentOrder(13);
    if (app.globalData.sendWifiFlag == 1)
      that.sendWifiMessage("d")
  },

  sendWifiMessage: function (wifiMsg) {
    var that = this;
    udpSocket.send({
      address: app.globalData.servWifiID,
      port: app.globalData.servWifiPort,
      message: wifiMsg
    })
  },

  initUdpSocket() {
    udpSocket = wx.createUDPSocket();
    const locationPort = udpSocket.bind()
    console.log(locationPort)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     //传入home页的数据
    var that = this;
    that.initUdpSocket();
    if (app.globalData.jumpflag == 0) {
      if (app.globalData.isIOS == "") {
        app.showModal1("请连接蓝牙或者WiFi");
      }
      if (app.globalData.isIOS != "") {
        app.showModal1("请点击扫描蓝牙或者初始化WiFi");
      }
    }

    deviceId = decodeURIComponent(options.deviceId);
    name = decodeURIComponent(options.name);
    serviceId = decodeURIComponent(options.serviceId);
    writeId = decodeURIComponent(options.writeCharacterId);
    notifyId = decodeURIComponent(options.notifyCharacterId);
    that.onBluetoothAdapterStateChange(); //监听手机蓝牙状态
    //that.onBLEConnectionStateChange();    //监听连接蓝牙连接状态  //onBLEConnectionStateChange20s左右才能回调得到异常断开的反馈
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var sendLastTop = 0;
    setTimeout(function () {
      wx.getSystemInfo({
        success: function (e) {
          sendLastTop = e.windowHeight - lastBottom - ganimgHeight;
          that.setData({
            lastTop: sendLastTop
          });
          lastTopThis = sendLastTop;
        }
      });
    }, 150);//等页面加载完再执行，不然有bug，因为数据还没传过去
 
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})