//app.js
App({
  globalData: {
     createflag : '', //连接标志
     jumpflag : 0 ,//可以跳转页面标志
     AdapterStateflag : 0,
     sendfail : 0,      //发送数据失败次数
     //wifi
    sendWifiFlag: 0,
    sendBleFlag: 0,
    servWifiID : "192.168.4.1",
    servWifiPort : 8266,
    isIOS: ""
  },

  onLaunch: function () {
    var that = this;
    that.globalData.jumpflag = 0;
    that.globalData.AdapterStateflag = 0;
    that.globalData.sendfail = 0;
    that.globalData.sendWifiFlag = 0;
    that.globalData.sendBleFlag = 0;
    that.globalData.servWifiID = "192.168.4.1";
    that.globalData.servWifiPort = 8266;
    that.globalData.isIOS = "";
  },

  getModel: function () { //获取手机型号
    return this.globalData.sysinfo["model"]
  },
  getWxVersion: function () { //获取微信版本号
    return this.globalData.sysinfo["version"]
  },
  getSystem: function () { //获取操作系统版本
    return this.globalData.sysinfo["system"]
  },
  getPlatform: function () { //获取客户端平台
    return this.globalData.sysinfo["platform"]
  },
  getSDKVersion: function () { //获取客户端基础库版本
    return this.globalData.sysinfo["SDKVersion"]
  },

  //toast提示
  toastTips: function (txt) {
    wx.showToast({
      title: txt
    })
  },
  //toast提示，可以设置等待时长
  toastTips1: function (txt, time) {
    wx.showToast({
      title: txt,
      duration: time
    })
  },
  toastTips2: function (txt) {
    wx.showToast({
      title: txt,
      icon: "loading"
    })
  },

  //弹窗提示
  showModal: function (txt) {
    wx.showModal({
      title: '提示',
      content: txt,
      showCancel: false,
    })
  },
  //弹窗提示,有确认按钮
  showModal1: function (txt) {
    wx.showModal({
      title: "提示",
      content: txt,
      showCancel: false,
      confirmText: "确定"
    })
  },
  //loading
  showLoading: function (txt) {
    wx.showLoading({
      title: txt,
      mask: true
    });
  },
  
  isBlank: function (str) {
    if (Object.prototype.toString.call(str) === '[object Undefined]') { //空
      return true
    } else if (
      Object.prototype.toString.call(str) === '[object String]' ||
      Object.prototype.toString.call(str) === '[object Array]') { //字条串或数组
      return str.length == 0 ? true : false
    } else if (Object.prototype.toString.call(str) === '[object Object]') {
      return JSON.stringify(str) == '{}' ? true : false
    } else {
      return true
    }

  },
  globalData: {
    userInfo: null,
    sysinfo: null
  }


})